/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.libregsystem;

/**
 *
 * @author Naseem
 */
public class LibRegSystem {

    public static void main(String[] args) {
       
    }
}
