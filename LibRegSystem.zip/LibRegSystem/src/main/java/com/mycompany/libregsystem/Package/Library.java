/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.libregsystem.Package;

import java.util.List;



public class Library {
    private List<Book> books;
    
    
    public void saveBooksToFile(String fileName) {
    List<String> bookData = null ;
        FileHandler.saveData(bookData, fileName);
    }
    
    public void loadBooksFromFile(String fileName) {
        List<String> bookData = FileHandler.loadData(fileName);
        
    }
}
