/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.libregsystem;

import java.util.Date;

public class Author implements Display {
    private String id;
    private String name;
    private String address;
    private Date birthDate;
    
     public Author(String id, String name, String address, Date birthDate) {
        this.id = id;
        this.name = name;
        this.address = address;
        this.birthDate = birthDate;
    }
     
      public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getAddress() {
        return address;
    }

    public Date getBirthDate() {
        return birthDate;
    }
    
    @Override
    public String getInfo() {
        return String.format("ID: %s, Name: %s, Address: %s, Birth Date: %s",
                id, name, address, birthDate.toString());
    }

    @Override
    public boolean inLoan() {
        return false;
    }
}
