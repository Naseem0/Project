/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.libregsystem.Package;

import com.mycompany.libregsystem.Package.Display;

/**
 *
 * @author Naseem
 */
public class Journal implements Display {
     private String conferenceName;
    private String conferenceNo;
    
     public Journal(String conferenceName, String conferenceNo) {
        this.conferenceName = conferenceName;
        this.conferenceNo = conferenceNo;
    }
     
      public String getConferenceName() {
        return conferenceName;
    }

    public String getConferenceNo() {
        return conferenceNo;
    }

    @Override
    public String getInfo() {
        return String.format("Conference Name: %s, Conference No: %s", conferenceName, conferenceNo);
    }

    @Override
    public boolean inLoan() {
        return false;
    }
}
